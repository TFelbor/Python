
# A class for stacks
class Stack(object):

    def __init__(self):
        pass

    def size(self):
        pass

    def push(self, item):
        pass

    def pop(self):
        pass

    def peek(self):
        pass

    def clear(self):
        pass

    def is_empty(self):
        pass

    def __str__(self):
        pass

