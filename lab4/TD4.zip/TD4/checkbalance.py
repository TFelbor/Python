from stack import Stack


def checkbalance(string):
    """
    Check the balance of the string 'string'
    :param string: the string to check
    :return: -1 if the string is balanced, or the
    index of the imbalanced otherwise
    """
    pass

def stop():
    while True:
        answer = input("more ('y' or 'n')? ").strip().lower()
        if answer == 'y':
            return False
        elif answer == 'n':
            return True

def main():
    print("Checking balance...")
    while True:
        string = input("your string: ")
        index = checkbalance(string)
        if index > -1:
            print("the string is not balanced:\n")
            print(string)
            print(' ' * index + '^')
        else:
            print("the string is balanced:\n")
        if stop():
            break
    print("done")

if __name__ == '__main__':
    main()
